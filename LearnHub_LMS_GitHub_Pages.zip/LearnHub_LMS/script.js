const $ = (id) => document.getElementById(id);
const today = new Date().toISOString().slice(0,10);
const starter = {
  students: [
    {id:"2026-001",name:"Alex Reyes",email:"alex.reyes@example.com",course:"BS Information Technology"},
    {id:"2026-002",name:"Jamie Cruz",email:"jamie.cruz@example.com",course:"BS Information Technology"},
    {id:"2026-003",name:"Taylor Santos",email:"taylor.santos@example.com",course:"BS Computer Science"}
  ],
  courses: [
    {code:"IT101",title:"Introduction to Computing",description:"Fundamental concepts of computers, information systems, and digital technology.",instructor:"Instructor Demo"},
    {code:"WEB201",title:"Web Development",description:"Learn the foundations of HTML, CSS, and JavaScript.",instructor:"Instructor Demo"},
    {code:"DBMS202",title:"Database Management",description:"Explore data organization, relational databases, and SQL basics.",instructor:"Instructor Demo"}
  ],
  attendance: {},
  grades: [
    {studentId:"2026-001",course:"Introduction to Computing",score:92},
    {studentId:"2026-002",course:"Web Development",score:88}
  ]
};
function loadData(){try{return JSON.parse(localStorage.getItem("learnhubData"))||structuredClone(starter)}catch{return structuredClone(starter)}}
let data=loadData(), modalType=null;
function save(){localStorage.setItem("learnhubData",JSON.stringify(data));renderAll()}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function initials(name){return name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase()}
function studentById(id){return data.students.find(s=>s.id===id)}
function emptyRow(cols,msg="No records found yet."){return `<tr><td class="empty" colspan="${cols}">${msg}</td></tr>`}
function showToast(message){const t=$("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function go(page){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$("page-"+page).classList.add("active");document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("pageCrumb").textContent=page[0].toUpperCase()+page.slice(1);$("sidebar").classList.remove("open");renderAll()}
function renderDashboard(){
  $("statStudents").textContent=data.students.length;$("statCourses").textContent=data.courses.length;
  $("statPresent").textContent=Object.values(data.attendance[today]||{}).filter(x=>x==="Present").length;
  $("statGrades").textContent=data.grades.length;
  $("todayDate").textContent=new Date().toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric",year:"numeric"});
  const rows=[...data.students].slice(-4).reverse();
  $("recentStudents").innerHTML=rows.length?rows.map(s=>`<tr><td><span class="student-name">${esc(s.name)}</span><span class="student-sub">${esc(s.email)}</span></td><td>${esc(s.id)}</td><td>${esc(s.course)}</td></tr>`).join(""):emptyRow(3);
}
function renderStudents(){
 const q=($("studentSearch").value||"").toLowerCase();
 const list=data.students.filter(s=>[s.name,s.id,s.email,s.course].some(v=>v.toLowerCase().includes(q)));
 $("studentCount").textContent=`${list.length} student(s)`;
 $("studentsTable").innerHTML=list.length?list.map(s=>`<tr><td><span class="student-name">${esc(s.name)}</span><span class="student-sub">${esc(s.email)}</span></td><td>${esc(s.id)}</td><td>${esc(s.email)}</td><td>${esc(s.course)}</td><td><button class="delete-btn" data-delete-student="${esc(s.id)}">Delete</button></td></tr>`).join(""):emptyRow(5,"No matching students. Add a student to get started.");
}
function renderCourses(){
 $("courseGrid").innerHTML=data.courses.length?data.courses.map((c,i)=>`<article class="course-card"><div class="course-top"><span class="course-symbol">${["▤","⌘","◈","✦"][i%4]}</span><button class="delete-btn" data-delete-course="${esc(c.code)}">Delete</button></div><h3>${esc(c.title)}</h3><p>${esc(c.description)}</p><div class="course-meta"><span>${esc(c.code)}</span><span>${esc(c.instructor)}</span></div></article>`).join(""): `<article class="panel empty">No courses yet. Add your first course.</article>`;
}
function renderAttendance(){
 const date=$("attendanceDate").value||today;const records=data.attendance[date]||{};
 $("attendanceTable").innerHTML=data.students.length?data.students.map(s=>`<tr><td><span class="student-name">${esc(s.name)}</span></td><td>${esc(s.id)}</td><td><select class="status-select attendance-status" data-id="${esc(s.id)}"><option ${records[s.id]==="Present"?"selected":""}>Present</option><option ${records[s.id]==="Absent"?"selected":""}>Absent</option><option ${records[s.id]==="Late"?"selected":""}>Late</option></select></td></tr>`).join(""):emptyRow(3,"Add students before recording attendance.");
}
function renderGrades(){
 $("gradeCount").textContent=`${data.grades.length} record(s)`;
 $("gradesTable").innerHTML=data.grades.length?data.grades.map((g,i)=>{const s=studentById(g.studentId);return `<tr><td>${s?esc(s.name):"Unknown student"}</td><td>${esc(g.course)}</td><td><span class="grade-pill ${g.score<75?"needs":""}">${g.score}</span></td><td>${g.score>=75?"Passed":"Needs improvement"}</td><td><button class="delete-btn" data-delete-grade="${i}">Delete</button></td></tr>`}).join(""):emptyRow(5,"No grades have been recorded.");
}
function renderAll(){renderDashboard();renderStudents();renderCourses();renderAttendance();renderGrades()}
function openModal(type){
 modalType=type;const fields=$("formFields");$("modalTitle").textContent={student:"Add Student",course:"Add Course",grade:"Add Grade"}[type];
 const courseOptions=data.courses.map(c=>`<option value="${esc(c.title)}">${esc(c.title)}</option>`).join("");
 const studentOptions=data.students.map(s=>`<option value="${esc(s.id)}">${esc(s.name)} (${esc(s.id)})</option>`).join("");
 if(type==="student")fields.innerHTML=`<div class="field"><label>Full name</label><input name="name" required maxlength="70" placeholder="e.g. Morgan Lee"></div><div class="field"><label>Student ID</label><input name="id" required maxlength="20" placeholder="e.g. 2026-004"></div><div class="field"><label>Email address</label><input name="email" type="email" required placeholder="student@example.com"></div><div class="field"><label>Program / Course</label><input name="course" required placeholder="e.g. BS Information Technology"></div>`;
 if(type==="course")fields.innerHTML=`<div class="field"><label>Course code</label><input name="code" required maxlength="15" placeholder="e.g. IT301"></div><div class="field"><label>Course title</label><input name="title" required placeholder="e.g. System Integration"></div><div class="field"><label>Description</label><input name="description" required placeholder="Short course description"></div><div class="field"><label>Instructor</label><input name="instructor" required placeholder="Instructor name"></div>`;
 if(type==="grade")fields.innerHTML=data.students.length&&data.courses.length?`<div class="field"><label>Student</label><select name="studentId" required>${studentOptions}</select></div><div class="field"><label>Course</label><select name="course" required>${courseOptions}</select></div><div class="field"><label>Grade (0–100)</label><input name="score" type="number" min="0" max="100" required placeholder="e.g. 90"></div>`:`<p class="muted">Add at least one student and one course before recording a grade.</p>`;
 $("modalBackdrop").classList.add("open");$("modalBackdrop").setAttribute("aria-hidden","false");
}
function closeModal(){$("modalBackdrop").classList.remove("open");$("modalBackdrop").setAttribute("aria-hidden","true");$("recordForm").reset();modalType=null}
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("menuToggle").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
$("addStudentBtn").addEventListener("click",()=>openModal("student"));$("addCourseBtn").addEventListener("click",()=>openModal("course"));$("addGradeBtn").addEventListener("click",()=>openModal("grade"));
$("closeModal").addEventListener("click",closeModal);$("cancelModal").addEventListener("click",closeModal);
$("modalBackdrop").addEventListener("click",e=>{if(e.target===$("modalBackdrop"))closeModal()});
$("studentSearch").addEventListener("input",renderStudents);
$("attendanceDate").value=today;$("attendanceDate").addEventListener("change",renderAttendance);
$("saveAttendanceBtn").addEventListener("click",()=>{const date=$("attendanceDate").value;if(!date){showToast("Please choose a date.");return}data.attendance[date]={};document.querySelectorAll(".attendance-status").forEach(sel=>data.attendance[date][sel.dataset.id]=sel.value);save();showToast("Attendance saved successfully.")});
$("recordForm").addEventListener("submit",e=>{
 e.preventDefault();const f=Object.fromEntries(new FormData(e.target).entries());
 if(modalType==="student"){if(data.students.some(s=>s.id.toLowerCase()===f.id.trim().toLowerCase())){showToast("That student ID already exists.");return}data.students.push({id:f.id.trim(),name:f.name.trim(),email:f.email.trim(),course:f.course.trim()})}
 if(modalType==="course"){if(data.courses.some(c=>c.code.toLowerCase()===f.code.trim().toLowerCase())){showToast("That course code already exists.");return}data.courses.push({code:f.code.trim(),title:f.title.trim(),description:f.description.trim(),instructor:f.instructor.trim()})}
 if(modalType==="grade"){const score=Number(f.score);if(score<0||score>100){showToast("Grade must be between 0 and 100.");return}data.grades.push({studentId:f.studentId,course:f.course,score})}
 closeModal();save();showToast("Record saved successfully.");
});
document.addEventListener("click",e=>{
 const student=e.target.dataset.deleteStudent,course=e.target.dataset.deleteCourse,grade=e.target.dataset.deleteGrade;
 if(student&&confirm("Delete this student and their grade records?")){data.students=data.students.filter(s=>s.id!==student);data.grades=data.grades.filter(g=>g.studentId!==student);Object.values(data.attendance).forEach(day=>delete day[student]);save();showToast("Student deleted.")}
 if(course&&confirm("Delete this course?")){data.courses=data.courses.filter(c=>c.code!==course);save();showToast("Course deleted.")}
 if(grade!==undefined&&confirm("Delete this grade record?")){data.grades.splice(Number(grade),1);save();showToast("Grade deleted.")}
});
renderAll();
